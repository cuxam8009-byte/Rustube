package com.rustube.app

import androidx.compose.foundation.background
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared spacing and shape values for the Signal Atelier visual system. */
object SignalSpace {
    val Screen = 18.dp
    val Section = 22.dp
    val CardGap = 14.dp
    val ControlGap = 8.dp
    val ControlHeight = 44.dp
}

object SignalShapes {
    val Control = RoundedCornerShape(14.dp)
    val Card = RoundedCornerShape(20.dp)
    val LargeCard = RoundedCornerShape(26.dp)
}

@Composable
fun SignalIconAction(
    icon: ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .size(44.dp)
            .shadow(2.dp, SignalShapes.Control, clip = false)
            .clip(SignalShapes.Control)
            .background(colors.surfaceContainerHigh)
            .border(1.dp, colors.outlineVariant.copy(alpha = 0.8f), SignalShapes.Control)
            .pressable(pressedScale = 0.92f, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = colors.onSurface,
            modifier = Modifier.size(20.dp),
        )
    }
}

@Composable
fun SignalPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    showArrow: Boolean = true,
) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(15.dp)
    Row(
        modifier = modifier
            .heightIn(min = 46.dp)
            .shadow(3.dp, shape, clip = false)
            .clip(shape)
            .background(colors.primary)
            .border(1.dp, colors.primary.copy(alpha = 0.9f), shape)
            .pressable(pressedScale = 0.97f, onClick = onClick)
            .padding(start = 15.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = colors.onPrimary, modifier = Modifier.size(18.dp))
        }
        Text(
            text,
            color = colors.onPrimary,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp,
            letterSpacing = 0.15.sp,
        )
        if (showArrow) {
            Box(
                modifier = Modifier
                    .size(31.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(colors.onPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = colors.onPrimary,
                    modifier = Modifier.size(16.dp),
                )
            }
        } else {
            Spacer(Modifier.width(3.dp))
        }
    }
}

@Composable
fun SignalEyebrow(text: String, modifier: Modifier = Modifier, color: Color? = null) {
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = color ?: MaterialTheme.colorScheme.primary,
        fontSize = 9.sp,
        lineHeight = 12.sp,
        letterSpacing = 1.65.sp,
        fontWeight = FontWeight.Black,
        maxLines = 1,
    )
}

/** Lightweight Rustube dock: opaque surface, fixed touch targets and a single active marker. */
@Composable
fun RustubeNavigationDock(
    selected: Tab,
    onSelect: (Tab) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    androidx.compose.material3.Surface(
        modifier = modifier
            .height(70.dp)
            .border(1.dp, colors.outlineVariant.copy(alpha = 0.78f), shape),
        shape = shape,
        color = colors.surfaceContainerLow,
        tonalElevation = 1.dp,
        shadowElevation = 7.dp,
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 5.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tab.entries.forEach { tab ->
                val active = tab == selected
                val special = tab == Tab.Shorts
                val accent = if (special) colors.tertiary else colors.primary
                val iconColor = if (active) {
                    if (special) colors.onTertiary else colors.onPrimary
                } else if (special) colors.tertiary else colors.onSurfaceVariant
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember(tab) { MutableInteractionSource() },
                            indication = null,
                        ) { onSelect(tab) }
                        .padding(horizontal = 1.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (active) 34.dp else 32.dp)
                            .clip(RoundedCornerShape(if (special) 11.dp else 10.dp))
                            .background(if (active) accent else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = if (active) tab.selectedIcon else tab.icon,
                            contentDescription = tab.label,
                            tint = iconColor,
                            modifier = Modifier.size(if (active) 20.dp else 19.dp),
                        )
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = tab.label.uppercase(),
                        color = if (active) colors.onSurface else colors.onSurfaceVariant,
                        fontSize = 8.sp,
                        lineHeight = 10.sp,
                        fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                        letterSpacing = 0.3.sp,
                        maxLines = 1,
                        softWrap = false,
                    )
                    Spacer(Modifier.height(2.dp))
                    Box(
                        Modifier
                            .width(if (active) 14.dp else 4.dp)
                            .height(2.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (active) accent else colors.outlineVariant.copy(alpha = 0.55f)),
                    )
                }
            }
        }
    }
}
