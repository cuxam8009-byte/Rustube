package com.rustube.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Rustube design language: "Ink & Paper".
 *
 *  - Two colours only. Ink (black in light mode, white in dark mode) and paper (the opposite). Greys are the
 *    only other tones. The selected state is always an ink pill with paper text.
 *  - Editorial cards: channel as a small upper-case kicker, the title as the headline, one quiet meta line.
 *  - One hero card on top of the feed, a floating dock whose selected tab opens into a pill.
 *  - Flat and cheap to draw: solid fills and hairlines, no blur, no shadows, no offscreen layers.
 */

private val baseTypography = Typography()

val RustubeTypography: Typography = baseTypography.copy(
    headlineLarge = baseTypography.headlineLarge.copy(fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = (-0.8).sp),
    headlineMedium = baseTypography.headlineMedium.copy(fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.6).sp),
    headlineSmall = baseTypography.headlineSmall.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp, letterSpacing = (-0.4).sp),
    titleLarge = baseTypography.titleLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.3).sp),
    titleMedium = baseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.2).sp),
    titleSmall = baseTypography.titleSmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp, letterSpacing = 0.sp),
    bodyLarge = baseTypography.bodyLarge.copy(fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.sp),
    bodyMedium = baseTypography.bodyMedium.copy(fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.sp),
    bodySmall = baseTypography.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.sp),
    labelLarge = baseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp, letterSpacing = 0.sp),
    labelMedium = baseTypography.labelMedium.copy(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.2.sp),
    labelSmall = baseTypography.labelSmall.copy(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.3.sp),
)

/** The app mark drawn in the theme's own colours: an ink square holding the paper gear-and-play glyph. */
@Composable
fun RustubeBadge(size: Dp = 32.dp) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(c.onSurface),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_launcher_monochrome),
            contentDescription = null,
            tint = c.surface,
            modifier = Modifier.requiredSize(size * 1.25f),
        )
    }
}

/** "Rus" in ink, "tube" in grey. */
@Composable
fun RustubeWordmark(modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        RustubeBadge(32.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = c.onSurface)) { append("Rus") }
                withStyle(SpanStyle(color = c.onSurfaceVariant)) { append("tube") }
            },
            fontWeight = FontWeight.Bold,
            fontSize = 30.sp,
            letterSpacing = (-1).sp,
            maxLines = 1,
        )
    }
}

/** A full-width search field that opens search when tapped. */
@Composable
fun HomeSearchPill(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .pressable(pressedScale = 0.985f, onClick = onClick)
            .height(46.dp)
            .clip(CircleShape)
            .background(c.surfaceContainer)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, contentDescription = null, tint = c.onSurfaceVariant, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            text = I18n.t("search_hint", "Search videos"),
            color = c.onSurfaceVariant,
            fontSize = 16.sp,
            maxLines = 1,
        )
    }
}

/**
 * Rustube's floating dock. Every tab is an icon; the selected one grows into an ink pill that also shows
 * its name. Same 64 dp height as before, so the screens above it keep their spacing.
 */
@Composable
fun RustubeDock(
    selected: Tab,
    onSelect: (Tab) -> Unit,
    onDark: Boolean,
    modifier: Modifier = Modifier,
) {
    val c = MaterialTheme.colorScheme
    val container = if (onDark) Color(0xFF0B0B0C).copy(alpha = 0.94f) else c.surfaceContainerLow.copy(alpha = 0.95f)
    val edge = if (onDark) Color(0xFF2C2C2E) else c.outlineVariant
    val ink = if (onDark) Color.White else c.onSurface
    val paper = if (onDark) Color.Black else c.surface
    val idle = if (onDark) Color(0xFF8E8E93) else c.onSurfaceVariant

    Row(
        modifier = modifier
            .height(64.dp)
            .clip(CircleShape)
            .background(container)
            .border(0.5.dp, edge, CircleShape)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Tab.entries.forEach { t ->
            val isSelected = t == selected
            val grow by animateFloatAsState(
                targetValue = if (isSelected) 2.4f else 1f,
                animationSpec = tween(240),
                label = "dockWeight",
            )
            val downloading = t == Tab.Downloads && Downloads.busy
            Box(
                modifier = Modifier
                    .weight(grow)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(if (isSelected) ink else Color.Transparent)
                    .pressable(pressedScale = 0.92f) { onSelect(t) },
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(26.dp), contentAlignment = Alignment.Center) {
                        if (downloading) {
                            CircularProgressIndicator(
                                progress = { Downloads.progress },
                                color = if (isSelected) paper else ink,
                                strokeWidth = 1.5.dp,
                                modifier = Modifier.size(26.dp),
                            )
                        }
                        Icon(
                            imageVector = if (isSelected) t.selectedIcon else t.icon,
                            contentDescription = t.label,
                            tint = if (isSelected) paper else idle,
                            modifier = Modifier.size(if (downloading) 16.dp else 22.dp),
                        )
                    }
                    if (isSelected) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = t.label,
                            color = paper,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                }
            }
        }
    }
}
