package com.rustube.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Typeface
import android.os.Build
import android.os.Debug
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.FrameMetrics
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.lang.ref.WeakReference
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** Ring of the most recent samples (ms). Writes are a couple of array stores, reads copy and sort. */
class PerfSeries(private val capacity: Int = 600) {
    private val buf = DoubleArray(capacity)
    private var n = 0
    private var sum = 0.0
    private var maxV = 0.0

    class Snapshot(
        val count: Int,
        val mean: Double,
        val p50: Double,
        val p90: Double,
        val p95: Double,
        val p99: Double,
        val max: Double,
    )

    @Synchronized
    fun add(v: Double) {
        buf[n % capacity] = v
        n++
        sum += v
        if (v > maxV) maxV = v
    }

    @Synchronized
    fun clear() {
        n = 0
        sum = 0.0
        maxV = 0.0
    }

    @Synchronized
    fun snapshot(): Snapshot {
        val k = minOf(n, capacity)
        val copy = buf.copyOf(k)
        copy.sort()
        fun pct(p: Double): Double = if (k == 0) 0.0 else copy[((k - 1) * p).toInt().coerceIn(0, k - 1)]
        return Snapshot(
            count = n,
            mean = if (n == 0) 0.0 else sum / n,
            p50 = pct(0.50),
            p90 = pct(0.90),
            p95 = pct(0.95),
            p99 = pct(0.99),
            max = maxV,
        )
    }
}

/**
 * Rustube measurement kit.
 *
 * Everything is cheap (a few array stores per sample) and stays on the phone: nothing is sent
 * anywhere. The numbers appear on the "Bản đo hiệu năng" screen, ready to copy or share.
 */
object Perf {
    private const val PREFS = "rustube_perf"

    // ------------------------------------------------------------------ start-up
    @Volatile private var processStartMs = 0L
    @Volatile private var appCreateStartMs = 0L
    @Volatile private var appCreateEndMs = 0L
    @Volatile private var firstFrameMs = 0L
    private val initSteps = ArrayList<Pair<String, Double>>()

    fun onAppCreateStart() {
        processStartMs = Process.getStartElapsedRealtime()
        appCreateStartMs = SystemClock.elapsedRealtime()
    }

    fun onAppCreateEnd() {
        appCreateEndMs = SystemClock.elapsedRealtime()
    }

    /** Runs [block] and remembers how long this start-up step took. */
    inline fun <T> step(name: String, block: () -> T): T {
        val t0 = System.nanoTime()
        try {
            return block()
        } finally {
            recordStep(name, (System.nanoTime() - t0) / 1e6)
        }
    }

    fun recordStep(name: String, ms: Double) {
        synchronized(initSteps) { initSteps.add(name to ms) }
    }

    private val marks = ArrayList<Pair<String, Long>>()

    /** Remembers a named moment so the report can show a start-up timeline. */
    fun mark(name: String) {
        val now = SystemClock.elapsedRealtime()
        synchronized(marks) { marks.add(name to now) }
    }

    // -------------------------------------------------------------------- frames
    private val frameTotal = PerfSeries(3000)
    private val frameUi = PerfSeries(3000)
    private val frameRender = PerfSeries(3000)
    private val frameGpu = PerfSeries(3000)
    private val frames = AtomicLong(0)
    private val slowFrames = AtomicLong(0)
    private val jankyFrames = AtomicLong(0)
    private val frozenFrames = AtomicLong(0)
    @Volatile private var resetAtMs = SystemClock.elapsedRealtime()
    @Volatile private var budgetMs = 16.67
    @Volatile private var refreshHz = 60f

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var owner: WeakReference<Activity>? = null
    private var listener: Window.OnFrameMetricsAvailableListener? = null

    private fun onFrame(m: FrameMetrics) {
        val total = m.getMetric(FrameMetrics.TOTAL_DURATION) / 1e6
        val uiMs = (
            m.getMetric(FrameMetrics.INPUT_HANDLING_DURATION) +
                m.getMetric(FrameMetrics.ANIMATION_DURATION) +
                m.getMetric(FrameMetrics.LAYOUT_MEASURE_DURATION) +
                m.getMetric(FrameMetrics.DRAW_DURATION)
            ) / 1e6
        val renderMs = (
            m.getMetric(FrameMetrics.SYNC_DURATION) +
                m.getMetric(FrameMetrics.COMMAND_ISSUE_DURATION) +
                m.getMetric(FrameMetrics.SWAP_BUFFERS_DURATION)
            ) / 1e6
        var budget = budgetMs
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            frameGpu.add(m.getMetric(FrameMetrics.GPU_DURATION) / 1e6)
            val deadline = m.getMetric(FrameMetrics.DEADLINE) / 1e6
            if (deadline > 1.0) budget = deadline
        }
        if (firstFrameMs == 0L && m.getMetric(FrameMetrics.FIRST_DRAW_FRAME) == 1L) {
            firstFrameMs = SystemClock.elapsedRealtime()
        }
        frameTotal.add(total)
        frameUi.add(uiMs)
        frameRender.add(renderMs)
        frames.incrementAndGet()
        winFrames.incrementAndGet()
        if (total > budget) {
            slowFrames.incrementAndGet()
            winSlow.incrementAndGet()
        }
        if (total > 2 * budget) jankyFrames.incrementAndGet()
        if (total > 700.0) frozenFrames.incrementAndGet()
        val us = (total * 1000).toLong()
        winMaxUs.updateAndGet { old -> if (us > old) us else old }
    }

    /** Starts recording frame timings of [activity]'s window. Call after setContent. */
    fun attach(activity: Activity) {
        runCatching {
            val old = owner?.get()
            val oldListener = listener
            if (old != null && oldListener != null) old.window.removeOnFrameMetricsAvailableListener(oldListener)

            @Suppress("DEPRECATION")
            val hz = activity.windowManager.defaultDisplay.refreshRate
            if (hz > 1f) {
                refreshHz = hz
                budgetMs = 1000.0 / hz
            }
            val t = thread ?: HandlerThread("rustube-perf").also {
                it.start()
                thread = it
            }
            val h = handler ?: Handler(t.looper).also { handler = it }
            val l = Window.OnFrameMetricsAvailableListener { _, metrics, _ -> onFrame(metrics) }
            activity.window.addOnFrameMetricsAvailableListener(l, h)
            listener = l
            owner = WeakReference(activity)
            applyOverlay(activity)
        }
    }

    fun detach(activity: Activity) {
        runCatching {
            val l = listener
            if (owner?.get() === activity && l != null) {
                activity.window.removeOnFrameMetricsAvailableListener(l)
                listener = null
                owner = null
            }
            removeOverlay()
        }
    }

    // ------------------------------------------------------- live FPS overlay
    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlay: TextView? = null
    private var ticking = false
    private val winFrames = AtomicLong(0)
    private val winSlow = AtomicLong(0)
    private val winMaxUs = AtomicLong(0)

    private val tick = object : Runnable {
        override fun run() {
            val tv = overlay
            if (tv == null) {
                ticking = false
                return
            }
            val n = winFrames.getAndSet(0)
            val slow = winSlow.getAndSet(0)
            val worst = winMaxUs.getAndSet(0) / 1000.0
            tv.text = String.format(
                Locale.US,
                "FPS %d · chậm %d · tệ nhất %.0f ms · %d Hz\nchạm để mở Bản đo",
                n, slow, worst, refreshHz.toInt(),
            )
            mainHandler.postDelayed(this, 1000L)
        }
    }

    fun overlayEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("overlay", false)

    fun setOverlayEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("overlay", on).apply()
        val a = owner?.get()
        if (a != null) applyOverlay(a) else if (!on) removeOverlay()
    }

    private fun applyOverlay(a: Activity) {
        if (overlayEnabled(a)) showOverlay(a) else removeOverlay()
    }

    private fun showOverlay(a: Activity) {
        removeOverlay()
        val density = a.resources.displayMetrics.density
        val tv = TextView(a)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.setBackgroundColor(0xCC000000.toInt())
        tv.textSize = 11f
        tv.typeface = Typeface.MONOSPACE
        val pad = (6 * density).toInt()
        tv.setPadding(pad, pad / 2, pad, pad / 2)
        tv.text = "Rustube · chạm để mở Bản đo"
        tv.isClickable = true
        tv.setOnClickListener { a.startActivity(Intent(a, PerfReportActivity::class.java)) }
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END,
        )
        lp.bottomMargin = (96 * density).toInt()
        lp.marginEnd = (8 * density).toInt()
        (a.window.decorView as ViewGroup).addView(tv, lp)
        overlay = tv
        if (!ticking) {
            ticking = true
            mainHandler.postDelayed(tick, 1000L)
        }
    }

    private fun removeOverlay() {
        val tv = overlay ?: return
        (tv.parent as? ViewGroup)?.removeView(tv)
        overlay = null
    }

    // ------------------------------------------------- named timers (network vs. rest)
    private val series = ConcurrentHashMap<String, PerfSeries>()
    private val httpCount = AtomicLong(0)
    private val httpBytes = AtomicLong(0)
    private val netTl = object : ThreadLocal<DoubleArray>() {
        override fun initialValue(): DoubleArray = DoubleArray(1)
    }

    fun record(name: String, ms: Double) {
        series.getOrPut(name) { PerfSeries(600) }.add(ms)
    }

    /** Called by the HTTP layer: time spent waiting for the network on the current thread. */
    fun addNet(ms: Double, bytes: Int) {
        netTl.get()!![0] += ms
        httpCount.incrementAndGet()
        httpBytes.addAndGet(bytes.toLong())
        record("HTTP · mỗi yêu cầu", ms)
    }

    @PublishedApi
    internal fun netNow(): Double = netTl.get()!![0]

    inline fun <T> time(name: String, block: () -> T): T {
        val t0 = System.nanoTime()
        try {
            return block()
        } finally {
            record(name, (System.nanoTime() - t0) / 1e6)
        }
    }

    /**
     * Times a blocking call and splits it into total / network / the rest. "The rest" is parsing,
     * PO-token work and filtering; it is what a Rust rewrite could actually shorten.
     * Only wrap code that runs on one thread (the network time is tracked per thread).
     */
    inline fun <T> timeSplit(name: String, block: () -> T): T {
        val n0 = netNow()
        val t0 = System.nanoTime()
        try {
            return block()
        } finally {
            val total = (System.nanoTime() - t0) / 1e6
            val net = netNow() - n0
            record("$name · tổng", total)
            record("$name · mạng", net)
            record("$name · xử lý (tổng trừ mạng)", (total - net).coerceAtLeast(0.0))
        }
    }

    fun reset() {
        frameTotal.clear()
        frameUi.clear()
        frameRender.clear()
        frameGpu.clear()
        frames.set(0)
        slowFrames.set(0)
        jankyFrames.set(0)
        frozenFrames.set(0)
        winFrames.set(0)
        winSlow.set(0)
        winMaxUs.set(0)
        series.clear()
        httpCount.set(0)
        httpBytes.set(0)
        resetAtMs = SystemClock.elapsedRealtime()
    }

    // ------------------------------------------------------------ JSON benchmark
    @Volatile var jsonBench: String = ""

    /** Parses two real YouTube responses with org.json: the baseline a Rust parser has to beat. */
    fun runJsonBench(ctx: Context): String {
        val out = StringBuilder()
        for (name in listOf("perf/search.json", "perf/comments.json")) {
            val text = try {
                ctx.assets.open(name).bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                out.append(name).append(": không đọc được (").append(e.javaClass.simpleName).append(")\n")
                continue
            }
            val parse = ArrayList<Double>()
            var first = 0.0
            var nodes = 0
            var walk = 0.0
            for (i in 0 until 8) {
                val t0 = System.nanoTime()
                val root = org.json.JSONObject(text)
                val t1 = System.nanoTime()
                if (i == 0) first = (t1 - t0) / 1e6 else parse.add((t1 - t0) / 1e6)
                if (i == 7) {
                    nodes = countNodes(root)
                    walk = (System.nanoTime() - t1) / 1e6
                }
            }
            val mean = parse.average()
            val best = parse.minOrNull() ?: 0.0
            out.append(
                String.format(
                    Locale.US,
                    "%s: %d KB · lần đầu %.1f ms · trung bình %.1f ms · nhanh nhất %.1f ms · duyệt %d nút %.1f ms\n",
                    name.substringAfterLast('/'), text.length / 1024, first, mean, best, nodes, walk,
                ),
            )
        }
        return out.toString()
    }

    private fun countNodes(o: Any?): Int = when (o) {
        is org.json.JSONObject -> {
            var c = 1
            val keys = o.keys()
            while (keys.hasNext()) c += countNodes(o.opt(keys.next()))
            c
        }
        is org.json.JSONArray -> {
            var c = 1
            for (i in 0 until o.length()) c += countNodes(o.opt(i))
            c
        }
        else -> 1
    }

    // -------------------------------------------------------------------- report
    fun buildReport(ctx: Context): String {
        val sb = StringBuilder()
        fun line(s: String = "") {
            sb.append(s).append('\n')
        }
        fun f1(v: Double): String = String.format(Locale.US, "%.1f", v)
        fun pctLine(label: String, s: PerfSeries.Snapshot): String =
            "$label: p50 ${f1(s.p50)} · p90 ${f1(s.p90)} · p99 ${f1(s.p99)} · max ${f1(s.max)} ms"

        val now = SystemClock.elapsedRealtime()
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val debuggable = (ctx.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val display = wm.defaultDisplay
        val modes = runCatching { display.supportedModes.map { it.refreshRate }.distinct().sorted() }
            .getOrDefault(emptyList())
        val modesText = modes.joinToString("/") { it.toInt().toString() }
        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL
        } else {
            Build.HARDWARE
        }

        line("=== RUSTUBE · BẢN ĐO ===")
        line("Phiên bản: ${BuildConfig.VERSION_NAME} (" + (if (debuggable) "DEBUG, số đo sẽ chậm hơn thật" else "release") + ")")
        line("Máy: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · chip $soc")
        line("RAM: ${mi.totalMem / 1048576} MB (còn ${mi.availMem / 1048576} MB) · máy RAM thấp: ${am.isLowRamDevice}")
        line("Màn hình: ${display.refreshRate.toInt()} Hz hiện tại · hỗ trợ: $modesText Hz")

        line()
        line("--- KHỞI ĐỘNG ---")
        if (processStartMs > 0 && appCreateEndMs > 0) {
            line("Tiến trình tạo → xong Application.onCreate: ${appCreateEndMs - processStartMs} ms (riêng onCreate: ${appCreateEndMs - appCreateStartMs} ms)")
        }
        if (processStartMs > 0 && firstFrameMs > 0) {
            line("Tiến trình tạo → khung hình đầu tiên: ${firstFrameMs - processStartMs} ms")
        } else {
            line("Khung hình đầu tiên: chưa ghi nhận (vuốt tắt app rồi mở lại từ đầu)")
        }
        val timeline = synchronized(marks) { marks.toList() }
        if (timeline.isNotEmpty() && processStartMs > 0) {
            line("Mốc thời gian (từ lúc tiến trình tạo):")
            timeline.forEach { line("  +${it.second - processStartMs} ms  ${it.first}") }
        }
        val steps = synchronized(initSteps) { initSteps.toList() }
        if (steps.isNotEmpty()) {
            line("Các bước khởi tạo (chậm nhất trước):")
            steps.sortedByDescending { it.second }.take(8).forEach { line("  ${f1(it.second)} ms  ${it.first}") }
            line("  tổng các bước: ${f1(steps.sumOf { it.second })} ms")
        }

        line()
        line("--- KHUNG HÌNH (từ lần đặt lại cách đây ${(now - resetAtMs) / 1000} giây) ---")
        val n = frames.get()
        if (n == 0L) {
            line("Chưa có khung hình nào. Dùng app (cuộn, mở video...) rồi bấm Làm mới.")
        } else {
            line("Số khung: $n · ngân sách ${f1(budgetMs)} ms/khung (${refreshHz.toInt()} Hz)")
            line("Chậm (quá ngân sách): ${slowFrames.get()} (${f1(100.0 * slowFrames.get() / n)}%)")
            line("Giật nặng (quá 2 lần): ${jankyFrames.get()} (${f1(100.0 * jankyFrames.get() / n)}%) · đứng >700ms: ${frozenFrames.get()}")
            line(pctLine("Tổng/khung", frameTotal.snapshot()))
            line(pctLine("UI thread ", frameUi.snapshot()))
            line(pctLine("Render    ", frameRender.snapshot()))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) line(pctLine("GPU       ", frameGpu.snapshot()))
            line("(UI = input+animation+layout+draw; Render = sync+lệnh vẽ+swap; phân vị trên tối đa 3000 khung gần nhất)")
        }

        val named = series.entries.sortedBy { it.key }
        if (named.isNotEmpty()) {
            line()
            line("--- THỜI GIAN CÁC TÁC VỤ (ms) ---")
            for (e in named) {
                val v = e.value.snapshot()
                line("${e.key}: n=${v.count} · tb ${f1(v.mean)} · p95 ${f1(v.p95)} · max ${f1(v.max)}")
            }
            line("HTTP: ${httpCount.get()} yêu cầu, ${httpBytes.get() / 1024} KB")
            line("(xử lý = tổng trừ thời gian HTTP: gồm parse JSON, PO token/WebView, lọc dữ liệu)")
        }

        val dbg = Debug.MemoryInfo()
        Debug.getMemoryInfo(dbg)
        val rt = Runtime.getRuntime()
        line()
        line("--- BỘ NHỚ ---")
        line("PSS ${dbg.totalPss / 1024} MB · Java heap ${(rt.totalMemory() - rt.freeMemory()) / 1048576} MB · native ${Debug.getNativeHeapAllocatedSize() / 1048576} MB")

        if (jsonBench.isNotEmpty()) {
            line()
            line("--- JSON: org.json trên máy này ---")
            sb.append(jsonBench)
        }
        return sb.toString()
    }
}
