package com.rustube.app

import android.os.SystemClock
import android.util.Log
import com.rustube.app.potoken.PoTokenGenerator
import java.util.concurrent.ConcurrentHashMap
import org.schabi.newpipe.extractor.services.youtube.PoTokenProvider
import org.schabi.newpipe.extractor.services.youtube.PoTokenResult

class RustubePoTokenProvider(private val generator: PoTokenGenerator) : PoTokenProvider {
    companion object {
        private const val TAG = "RustubePoTokenProvider"
        private const val CACHE_TTL_MS = 60_000L

        /**
         * One session id for the whole process while signed out. It used to be built from the current time on
         * every call, so every call looked like a brand-new session and re-created the PO-token WebView:
         * seconds of work on a mid-range phone, several times per video.
         */
        val guestSessionId: String = "guest_" + System.currentTimeMillis()
    }

    private class Cached(val at: Long, val sessionId: String, val result: PoTokenResult)

    private val cache = ConcurrentHashMap<String, Cached>()

    private fun resolvePoToken(videoId: String?): PoTokenResult? {
        videoId ?: return null
        return try {
            val sessionId = Account.visitorData() ?: guestSessionId
            val now = SystemClock.elapsedRealtime()
            val hit = cache[videoId]
            if (hit != null && hit.sessionId == sessionId && now - hit.at < CACHE_TTL_MS) return hit.result
            val res = Perf.time("PO token (WebView, mỗi lần tạo)") {
                generator.getWebClientPoToken(videoId, sessionId)
            } ?: return null
            val out = PoTokenResult(
                sessionId,
                res.playerRequestPoToken,
                res.streamingDataPoToken
            )
            cache[videoId] = Cached(now, sessionId, out)
            if (cache.size > 24) cache.entries.removeIf { now - it.value.at >= CACHE_TTL_MS }
            out
        } catch (e: Exception) {
            Log.w(TAG, "Failed to generate PoToken for $videoId: ${e.message}")
            null
        }
    }

    override fun getWebClientPoToken(videoId: String?): PoTokenResult? = resolvePoToken(videoId)

    override fun getWebEmbedClientPoToken(videoId: String?): PoTokenResult? = resolvePoToken(videoId)

    override fun getAndroidClientPoToken(videoId: String?): PoTokenResult? = resolvePoToken(videoId)

    override fun getIosClientPoToken(videoId: String?): PoTokenResult? = resolvePoToken(videoId)
}
