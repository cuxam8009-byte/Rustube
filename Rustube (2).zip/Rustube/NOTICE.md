# Notice

Rustube is derived from **YTXTube** (https://github.com/Koustubh12345/YTXTube), which is licensed under the
GNU General Public License v3.0. Rustube is distributed under the same license; the full text is in `LICENSE`.

## Modifications (2026-11-22)

- Package, application id, app name, icon and in-app branding replaced.
- Liquid Glass shaders and backdrop capture layers removed; translucent Apple-style surfaces and palette added.
- Start-up: the PO-token WebView warm-up moved out of `Application.onCreate`.
- Built-in measurement screen (frame timings, start-up steps, network vs. processing time, JSON benchmark).
- Upstream update feed, author links and donation/website material removed.
- Rustube "Ink & Paper" design language: monochrome palette, typography, editorial video cards with a hero card, floating pill dock, new wordmark and icon.
- Fixes: the PO-token WebView is no longer re-created on every call while signed out; the downloads folder scan no longer blocks start-up.
