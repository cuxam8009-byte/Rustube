package com.rustube.app

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.memory.MemoryCache
import com.rustube.app.potoken.PoTokenGenerator
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamExtractor

private const val PO_TOKEN_WARMUP_DELAY_MS = 2500L

class RustubeApplication : Application(), ImageLoaderFactory {

    companion object {
        lateinit var appContext: Context
            private set
    }

    override fun onCreate() {
        Perf.onAppCreateStart()
        super.onCreate()
        appContext = applicationContext
        Perf.step("TvMode.init") { TvMode.init(this) }
        Perf.step("LanguageSettings.init") { LanguageSettings.init(this) }
        Perf.step("GlassQuality.init") { GlassQuality.init(this) }
        Perf.step("GlassSettings.init") { GlassSettings.init(this) }
        Perf.step("NetworkSpeed.init") { NetworkSpeed.init(this) }
        Perf.step("PlaybackBandwidth.init") { PlaybackBandwidth.init(this) }
        Perf.step("NewPipe.init") { NewPipe.init(NewPipeDownloader.instance) }


        val poTokenGenerator = PoTokenGenerator()
        YoutubeStreamExtractor.setPoTokenProvider(RustubePoTokenProvider(poTokenGenerator))
        // Rustube: this used to create the PO-token WebView inside onCreate, on the main thread,
        // right where the first frame is being prepared. Warm it up a little later instead; the
        // provider still creates it on demand when a video is opened sooner.
        Handler(Looper.getMainLooper()).postDelayed({ poTokenGenerator.initialize() }, PO_TOKEN_WARMUP_DELAY_MS)


        YoutubeStreamExtractor.setFetchIosClient(true)
        Perf.step("HdrItags.install") { HdrItags.install() }
        Perf.step("ThemeSettings.init") { ThemeSettings.init(this) }
        Perf.step("HdrSupport.init") { HdrSupport.init(this) }
        Perf.step("QualityPreference.init") { QualityPreference.init(this) }
        Perf.step("PlaybackSpeed.init") { PlaybackSpeed.init(this) }
        Perf.step("AudioOnly.init") { AudioOnly.init(this) }
        Perf.step("AudioTrackPreference.init") { AudioTrackPreference.init(this) }
        Perf.step("CaptionPreference.init") { CaptionPreference.init(this) }
        Perf.step("VideoGestureSettings.init") { VideoGestureSettings.init(this) }
        Perf.step("PlayerControlSettings.init") { PlayerControlSettings.init(this) }
        Perf.step("PipSettings.init") { PipSettings.init(this) }
        Perf.step("MiniPlayerSettings.init") { MiniPlayerSettings.init(this) }
        Perf.step("ResumeStore.init") { ResumeStore.init(this) }
        Perf.step("Account.init") { Account.init(this) }
        Perf.step("SponsorBlock.init") { SponsorBlock.init(this) }
        Perf.step("SearchHistory.init") { SearchHistory.init(this) }
        Perf.step("Downloads.init") { Downloads.init(this) }

        getSystemService(android.net.ConnectivityManager::class.java)?.registerDefaultNetworkCallback(
            object : android.net.ConnectivityManager.NetworkCallback() {
                private var last: android.net.Network? = null
                override fun onAvailable(network: android.net.Network) {
                    if (last != null && last != network) StreamCache.invalidateAll()
                    last = network
                }
            },
        )
        Perf.onAppCreateEnd()
    }


    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .crossfade(180)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
        .build()
}
