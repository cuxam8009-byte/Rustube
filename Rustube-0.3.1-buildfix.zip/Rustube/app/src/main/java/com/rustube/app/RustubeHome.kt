package com.rustube.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material.icons.rounded.TravelExplore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RustubeDiscoverScreen(
    lib: LibraryData,
    contentPadding: PaddingValues,
    onOpen: (VideoItem) -> Unit,
    onSearch: () -> Unit,
    onSignIn: () -> Unit,
    onAccount: () -> Unit,
    scrollToTop: Int = 0,
) {
    val signedIn = Account.signedIn
    var activeFilter by remember { mutableStateOf(HomeFilter.All) }
    val gridState = rememberLazyGridState()

    LaunchedEffect(signedIn) {
        if (lib.home.videos.isEmpty()) lib.home.ensureLoaded()
        if (signedIn && lib.channels.isEmpty()) lib.loadChannels()
    }
    LaunchedEffect(activeFilter) {
        if (activeFilter == HomeFilter.Subscribed && lib.channels.isEmpty()) lib.loadChannels()
        gridState.scrollToItem(0)
    }
    LaunchedEffect(scrollToTop, lib.home.generation) {
        if (scrollToTop > 0) gridState.animateScrollToItem(0)
    }

    // Read the feed and channel SnapshotStateLists during composition. Do not memoize
    // their list objects: the same list instance is mutated as pages arrive.
    val videos = when (activeFilter) {
        HomeFilter.All -> lib.home.videos.toList()
        HomeFilter.Today -> lib.home.videos.filter {
            val uploaded = it.uploaded?.lowercase().orEmpty()
            uploaded.contains("hour") || uploaded.contains("minute") || uploaded.contains("second") ||
                uploaded.contains("just now") || uploaded.contains("1 day") || uploaded == "today" ||
                uploaded.contains("giờ") || uploaded.contains("phút") || uploaded.contains("vừa xong") ||
                uploaded.contains("hôm nay") || uploaded.contains("ngày")
        }
        HomeFilter.Videos -> lib.home.videos.filter { !it.isLive }
        HomeFilter.Subscribed -> {
            val channelNames = lib.channels.map { it.name.trim().lowercase() }.filter { it.isNotBlank() }.toSet()
            val channelIds = lib.channels.map { it.id.trim() }.filter { it.isNotBlank() }.toSet()
            lib.home.videos.filter { video ->
                val videoChannelId = video.channelId()
                val channelName = video.channel.trim().lowercase()
                (videoChannelId != null && videoChannelId in channelIds) ||
                    channelName in channelNames || lib.channels.any { video.fromChannel(it) }
            }
        }
        HomeFilter.Live -> lib.home.videos.filter { it.isLive }
    }
    val nearEnd by remember(gridState) {
        derivedStateOf {
            val lastVisible = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            gridState.layoutInfo.totalItemsCount > 0 && lastVisible >= gridState.layoutInfo.totalItemsCount - 4
        }
    }
    LaunchedEffect(nearEnd, videos.size, lib.home.hasMore, lib.home.loading) {
        if (nearEnd && videos.isNotEmpty() && lib.home.hasMore && !lib.home.loading) lib.home.loadMore()
    }

    PullToRefresh(
        enabled = true,
        refreshing = lib.home.refreshing,
        onRefresh = lib.home::refresh,
        topPadding = 0.dp,
    ) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 132.dp),
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                top = 8.dp,
                end = 16.dp,
                bottom = contentPadding.calculateBottomPadding() + 16.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(17.dp),
        ) {
            item(key = "rustube_discover_heading", span = { GridItemSpan(maxLineSpan) }) {
                DiscoverHeading(onSearch = onSearch, onAccount = onAccount)
            }
            item(key = "rustube_filter_rail", span = { GridItemSpan(maxLineSpan) }) {
                DiscoverFilterRail(selected = activeFilter, onSelect = { activeFilter = it })
            }
            if (!signedIn) {
                item(key = "rustube_guest_card", span = { GridItemSpan(maxLineSpan) }) {
                    GuestAccessCard(onSignIn = onSignIn)
                }
            }
            if (videos.isNotEmpty()) {
                item(key = "rustube_feature", span = { GridItemSpan(maxLineSpan) }) {
                    DiscoverFeature(video = videos.first(), onOpen = { onOpen(videos.first()) })
                }
                item(key = "rustube_picks_heading", span = { GridItemSpan(maxLineSpan) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            SignalEyebrow("THE LATEST SIGNAL")
                            Text(
                                if (activeFilter == HomeFilter.All) "Picked for you" else activeFilter.label,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-0.7).sp,
                            )
                        }
                        Text(
                            "${videos.size} STORIES",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp,
                        )
                    }
                }
                items(videos.drop(1), key = { "discover_${it.id}" }) { video ->
                    DiscoverVideoTile(video = video, onOpen = { onOpen(video) })
                }
            } else if (lib.home.loading) {
                item(key = "rustube_home_loading", span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().padding(vertical = 42.dp), contentAlignment = Alignment.Center) {
                        androidx.compose.material3.CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }
            } else {
                item(key = "rustube_home_empty", span = { GridItemSpan(maxLineSpan) }) {
                    EmptyState(
                        icon = if (activeFilter == HomeFilter.Subscribed) Icons.Rounded.Subscriptions else Icons.Rounded.TravelExplore,
                        title = "No ${activeFilter.label.lowercase()} videos",
                        body = if (activeFilter == HomeFilter.Subscribed)
                            "No videos from your subscribed channels were found in the current home feed."
                        else
                            "There are no ${activeFilter.label.lowercase()} videos in your feed right now.",
                        action = { SignalPrimaryButton("SHOW EVERYTHING", { activeFilter = HomeFilter.All }) },
                    )
                }
            }
            if (lib.home.error != null && videos.isEmpty()) {
                item(key = "rustube_home_error", span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        lib.home.error.orEmpty(),
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        fontSize = 13.sp,
                    )
                }
            }
            if (lib.home.loading && videos.isNotEmpty()) {
                item(key = "rustube_home_more", span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().padding(18.dp), contentAlignment = Alignment.Center) {
                        androidx.compose.material3.CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DiscoverHeading(onSearch: () -> Unit, onAccount: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 4.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BrandMark()
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                SignalEyebrow("RUSTUBE  /  DISCOVER")
                Text(
                    "Your next story.",
                    color = c.onSurface,
                    fontSize = 23.sp,
                    lineHeight = 26.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.8).sp,
                )
            }
            CircleAction(Icons.Rounded.Search, "Search", onSearch)
            Spacer(Modifier.width(7.dp))
            CircleAction(Icons.Rounded.AccountCircle, "Account", onAccount)
        }
        Text(
            "A better signal is one tap away.",
            color = c.onSurfaceVariant,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 2.dp),
        )
    }
}

@Composable
private fun DiscoverFilterRail(selected: HomeFilter, onSelect: (HomeFilter) -> Unit) {
    val c = MaterialTheme.colorScheme
    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 2.dp),
    ) {
        items(HomeFilter.entries.size) { index ->
            val filter = HomeFilter.entries[index]
            val active = filter == selected
            val shape = RoundedCornerShape(10.dp)
            Row(
                modifier = Modifier
                    .clip(shape)
                    .background(if (active) c.primary else c.surfaceContainerLow)
                    .border(1.dp, if (active) c.primary else c.outlineVariant.copy(alpha = 0.7f), shape)
                    .pressable(pressedScale = 0.96f) { onSelect(filter) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (active) Box(Modifier.size(5.dp).clip(CircleShape).background(c.onPrimary))
                Text(
                    filter.label.uppercase(),
                    color = if (active) c.onPrimary else c.onSurfaceVariant,
                    fontSize = 9.sp,
                    letterSpacing = 0.7.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun GuestAccessCard(onSignIn: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(c.secondaryContainer.copy(alpha = 0.62f))
            .border(1.dp, c.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
            .pressable(pressedScale = 0.985f, onClick = onSignIn)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(c.secondary), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.AccountCircle, null, tint = c.onSecondary, modifier = Modifier.size(23.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Make it yours", color = c.onSurface, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            Text("Sign in to sync your library and subscriptions.", color = c.onSurfaceVariant, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Text("JOIN ↗", color = c.onSurface, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = 0.5.sp)
    }
}

@Composable
private fun DiscoverFeature(video: VideoItem, onOpen: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.surfaceContainerLow)
            .border(1.dp, c.outlineVariant.copy(alpha = 0.7f), shape)
            .pressable(pressedScale = 0.99f, onClick = onOpen),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(204.dp)
                .background(c.surfaceContainerHigh),
        ) {
            Thumbnail(video.thumbnail, Modifier.fillMaxSize(), radius = 0, videoId = video.id)
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.18f),
                        0.43f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.83f),
                    ),
                ),
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                Box(Modifier.clip(RoundedCornerShape(6.dp)).background(c.primary).padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Text("RUSTUBE SELECT", color = c.onPrimary, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp)
                }
                if (video.isLive) {
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(c.tertiary).padding(horizontal = 7.dp, vertical = 5.dp)) {
                        Text("LIVE", color = c.onTertiary, fontSize = 8.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            DurationPill(video.durationSec, Modifier.align(Alignment.BottomEnd).padding(12.dp), small = true, isLive = video.isLive)
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                SignalEyebrow("FEATURE  /  01", color = Color(0xFFD6FF55))
                Text(
                    video.title,
                    color = Color.White,
                    fontSize = 19.sp,
                    lineHeight = 23.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ChannelAvatar(video.feedAvatar(), video.channel, size = 30)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(video.channel, color = c.onSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(metaLine(video.channel, video.views, video.uploaded, video.isLive), color = c.onSurfaceVariant, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(
                Modifier.clip(RoundedCornerShape(10.dp)).background(c.primary).padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = c.onPrimary, modifier = Modifier.size(15.dp))
                Text("WATCH", color = c.onPrimary, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 0.6.sp)
            }
        }
    }
}

@Composable
private fun DiscoverVideoTile(video: VideoItem, onOpen: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val menu = LocalVideoMenu.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .prefetchOnPress(video.id)
            .pressable(pressedScale = 0.975f, onLongClick = { menu(video) }, onClick = onOpen),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1.48f).clip(RoundedCornerShape(15.dp)).background(c.surfaceContainerHigh),
        ) {
            Thumbnail(video.thumbnail, Modifier.fillMaxSize(), radius = 15, videoId = video.id)
            DurationPill(video.durationSec, Modifier.align(Alignment.BottomEnd).padding(7.dp), small = true, isLive = video.isLive)
            ResumeBar(video.id, Modifier.align(Alignment.BottomStart).clip(RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp)))
            Box(
                Modifier.align(Alignment.TopStart).padding(7.dp).clip(RoundedCornerShape(5.dp))
                    .background(Color.Black.copy(alpha = 0.68f)).padding(horizontal = 6.dp, vertical = 4.dp),
            ) {
                Text(if (video.isLive) "ON AIR" else "RUSTUBE", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = 0.6.sp)
            }
        }
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            ChannelAvatar(video.feedAvatar(), video.channel, size = 25)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    video.title,
                    color = c.onSurface,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    metaLine(video.channel, video.views, video.uploaded, video.isLive),
                    color = c.onSurfaceVariant,
                    fontSize = 9.sp,
                    lineHeight = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
