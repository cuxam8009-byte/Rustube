# Rustube performance baseline — HONOR WOD-LX2

This is the user-supplied baseline for Rustube `0.2.0-measure` on HONOR WOD-LX2, Android 14 / API 34, MediaTek MT6765, 60 Hz. It is retained so later measurements can be compared against the same device and refresh-rate conditions.

## Baseline supplied by the device report

| Measurement | Baseline |
|---|---:|
| `Application.onCreate` completed | 1,663 ms from process start |
| `Application.onCreate` itself | 1,479 ms |
| First frame | 3,510 ms from process start |
| `Downloads.init` | 1,339.3 ms |
| Late frames | 978 / 5,414 (18.1%) |
| Severe frames (> 2 frame budgets) | 58 (1.1%) |
| Frames over 700 ms | 3 |
| Frame total p50 / p90 / p99 / max | 29.6 / 48.6 / 95.9 / 1,890.1 ms |
| UI p50 / p90 / p99 / max | 1.6 / 5.9 / 17.6 / 921.9 ms |
| Render p50 / p90 / p99 / max | 16.1 / 19.7 / 24.4 / 705.2 ms |
| GPU p50 / p90 / p99 / max | 8.7 / 12.5 / 18.3 / 63.9 ms |
| StreamInfo total / network / residual mean | 8,464.3 / 2,212.1 / 6,252.2 ms |
| Video details total / network / residual mean | 6,695.4 / 1,404.4 / 5,291.0 ms |
| Search total / network / residual mean | 2,453.4 / 1,285.9 / 1,167.6 ms |
| PSS / Java heap / native | 153 / 23 / 34 MB |

The “residual” values above are **total minus measured HTTP time**, not CPU time. They may include parsing, waits, PO-token generation, WebView work, locks, or other extractor processing. They must not be attributed to one cause without separate instrumentation.

## Changes in this build

1. `Downloads.init` now initializes the default directory and schedules preference/snapshot restoration on `Dispatchers.IO`; it no longer parses the saved JSON or scans the downloads directory synchronously during application startup.
2. The queue is held until restoration finishes, then the saved custom directory and task snapshot are applied before queued tasks can start. This prevents a download triggered during restore from being written to the wrong directory.
3. Main tab switching no longer uses `AnimatedContent`, avoiding simultaneous composition/drawing of outgoing and incoming full screens during each tab change.
4. The full-screen blurred image wash behind the player was replaced with a static color wash. No full-screen `Modifier.blur` remains in the app UI sources.
5. Added separate measurements for PO-token warm-up, PO-token request, WebView preparation, player-token generation, and wait time when a caller joins a shared in-flight StreamInfo extraction.

## Re-test protocol

After installing the same release variant on the same HONOR device, restart the app after force-stop, then:

- Capture startup and first-frame timings after a cold start.
- Scroll Home for at least 30 seconds and record frame/UI/Render/GPU percentiles.
- Open the same video IDs used previously; capture StreamInfo and video-details measurements.
- Repeat search with comparable queries.
- Compare the new `Downloads.restore.async`, PO-token and shared-extraction metrics with the baseline. The original baseline has no equivalent separate PO-token/shared-extraction samples, so those are diagnostic additions rather than direct before/after comparisons.

No post-change FPS or latency improvement is claimed until a new report is captured on the device.
