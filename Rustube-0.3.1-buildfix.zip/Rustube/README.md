# Rustube

Ứng dụng xem video cho Android (Kotlin + Jetpack Compose), sử dụng hệ nhận diện Signal Atelier của Rustube:
nền than chì, màu nhấn lime, các bề mặt phân lớp và component bo góc có phân cấp rõ ràng.
Hiệu ứng blur/shader Liquid Glass không được dùng trên thanh điều hướng hoặc các điều khiển mới; ưu tiên hiệu năng trên điện thoại phổ thông.

## Giao diện Rustube · Signal Atelier

Rustube dùng bố cục khám phá dạng lưới biên tập, Library dạng kho cá nhân, Music Desk, Offline Vault và thanh điều hướng dock riêng.
Design tokens và component dùng chung đặt trong `app/src/main/java/com/rustube/app/SignalDesign.kt`; giao diện được xây bằng Jetpack Compose và thích ứng theo kích thước màn hình.
Theme Signal Atelier là mặc định cho cài đặt mới; các bảng màu bổ sung được đặt tên theo hệ nhận diện Rustube.
Các luồng tìm kiếm, tài khoản, tải xuống, phát video/nhạc và dữ liệu kênh tiếp tục dùng module hiện có.

## Bản đo hiệu năng

Mở app, chạm vào ô **FPS** nổi ở góc dưới bên phải (hoặc Cài đặt, mục Appearance & Theme, rồi Bản đo hiệu năng).
Màn hình này cho xem và sao chép: FPS và khung giật (UI / render / GPU), thời gian từng bước khởi động,
thời gian mạng và thời gian xử lý của từng tác vụ, bộ nhớ, và tốc độ parse JSON trên máy.
Bản này ghi thêm thời gian warm-up PO token, chuẩn bị WebView và tạo player token để khoanh vùng độ trễ mở video.
Khôi phục danh sách tải xuống chạy trên `Dispatchers.IO`, không quét thư mục trong luồng khởi động giao diện. Hàng đợi chỉ bắt đầu sau khi phục hồi xong thư mục và trạng thái cũ. Xem `docs/benchmarks/honor-wod-lx2-baseline.md` để biết số đo trước tối ưu và các phép đo bổ sung.

## Build

Chạy workflow **Build & Release** trên GitHub Actions (hoặc `./gradlew :app:assembleRelease`). Có kèm workflow **Build Rustube (from zip)** để build khi đưa ZIP dự án vào repo. Cần JDK 21 và Android SDK phù hợp với `compileSdk` của project.

Project đã được đóng gói mà không kèm `app/rustube.keystore`. Để ký bản release bằng khóa hiện có, giữ khóa riêng tư ở đúng đường dẫn `app/rustube.keystore` và cấu hình GitHub Actions secrets `KEYSTORE_PASSWORD` và `KEY_PASSWORD` (cùng `KEY_ALIAS` nếu alias khác `rustube`). Nếu không có keystore, Gradle dùng debug signing để tạo APK thử nghiệm; APK đó không thay thế được bản cài đặt đã ký bằng khóa phát hành trước đây.

## Giấy phép

GPL-3.0, xem `LICENSE`. Nguồn gốc và các thay đổi được ghi trong `NOTICE.md`.
